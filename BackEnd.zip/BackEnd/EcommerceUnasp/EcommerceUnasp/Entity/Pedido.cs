﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceUnasp.Entity
{
    public class Pedido
    {
        public int Id { get; set; }

        [ForeignKey("Usuario")]
        public int UsuarioID { get; set; }

        public Usuario Usuario { get; set; }

        public int numProduto { get; set; }

        public DateTime dataEnvio { get; set; }

        public string estado { get; set; }

     //   public IEnumerable<Pedido> Pedidos { get; set; }

    }
}
