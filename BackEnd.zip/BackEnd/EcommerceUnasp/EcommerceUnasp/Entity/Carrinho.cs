﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceUnasp.Entity
{
    public class Carrinho
    {
        public int Id { get; set; }

        public int numProduto { get; set; }

        public int quantidade { get; set; }

        public float valorProduto { get; set; }


    }
}
