﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceUnasp.Entity
{
    public class Cliente
    {
        public int Id { get; set; }

        private string nomeCliente { get; set; }

        private string logradouro { get; set; }

        private string email { get; set; }

        private string cpf { get; set; }

        private DateTime dataNascimento { get; set; }

        private string senha { get; set; }

        public Perfil Perfil { get; set; }

    }
}
