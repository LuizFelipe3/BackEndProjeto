﻿using EcommerceUnasp.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceUnasp.Context
{
    public class MyContext : DbContext
    {
        public DbSet<Usuario> Usuarios { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("data source=45.93.100.120,1433;initial catalog=aereo;persist security info=True;user id=suporte;password=suporte;MultipleActiveResultSets=True;App=exeEf;");
        }

        protected override void OnModelCreating(ModelBuilder biulder)
        {
            base.OnModelCreating(biulder);

        }

    }
}
